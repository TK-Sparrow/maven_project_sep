

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class EncoderApp {
	public static void main(String args[]) {
		
	
		String enCode=new BCryptPasswordEncoder().encode("user");
		System.out.println(enCode);
	}
	
}
