package com.virtusa.shopping.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="Day14USER_ROLES")
public class UserRoles {
	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="USERNAME")
	private User user;
	
	@Id
	@Column(name="ROLE")
	private String userRoles;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(String userRoles) {
		this.userRoles = userRoles;
	}
	

}
