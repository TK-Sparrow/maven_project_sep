package com.virtusa.shopping.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="day14ProductQuantity")
public class ProductQuantity {
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name="Product_Quantity_Id")
		private int productQuantityId;
		
		@Column(name="Purchase_Quantity")
		private int purchaseQuantity;
		
		@Column(name="Purchase_Amount")
		private long amount;

		public int getProductQuantityId() {
			return productQuantityId;
		}

		public void setProductQuantityId(int productQuantityId) {
			this.productQuantityId = productQuantityId;
		}

		public int getPurchaseQuantity() {
			return purchaseQuantity;
		}

		public void setPurchaseQuantity(int purchaseQuantity) {
			this.purchaseQuantity = purchaseQuantity;
		}

		public long getAmount() {
			return amount;
		}

		public void setAmount(long amount) {
			this.amount = amount;
		}
		
}
