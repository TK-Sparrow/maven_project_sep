package com.virtusa.shopping.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Day14USERS")
public class User {
	
	@Id
	@Column(name="User_name")
	private String userName;

	@Column(name="Password")
	private String password;

	@Column(name="Enabled")
	private byte enabled;
	
	@OneToMany(cascade =CascadeType.ALL,mappedBy = "user")
	private List<UserRoles> userRole;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public byte getEnabled() {
		return enabled;
	}

	public void setEnabled(byte enabled) {
		this.enabled = enabled;
	}

	public List<UserRoles> getUserRole() {
		return userRole;
	}

	public void setUserRole(List<UserRoles> userRole) {
		this.userRole = userRole;
	}
	
	

}
