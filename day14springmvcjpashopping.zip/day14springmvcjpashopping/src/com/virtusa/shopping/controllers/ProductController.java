package com.virtusa.shopping.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.virtusa.shopping.models.Category;
import com.virtusa.shopping.models.Product;
import com.virtusa.shopping.services.CategoryService;
import com.virtusa.shopping.services.ProductService;

@Controller
public class ProductController {
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private ProductService productService;

	@GetMapping("/addproduct")
	public String addProduct() {
		return "addproduct";

	}

	@ModelAttribute("categories")
	public List<Category> getAllCategories() {
		return categoryService.getAllCategories();
	}
	
	@PostMapping("/saveproduct")
	public String saveProduct(@ModelAttribute Product product,@RequestParam String categoryId,Model model) {
		String data=categoryId.split("-")[0];
		System.out.println("idddd:"+data);
		model.addAttribute("product",productService.saveProduct(product, Integer.parseInt(data)));
		return "addproduct";
		
	}

}
