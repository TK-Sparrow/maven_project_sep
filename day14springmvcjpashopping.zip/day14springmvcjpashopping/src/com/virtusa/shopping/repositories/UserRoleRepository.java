package com.virtusa.shopping.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.shopping.models.UserRoles;

public interface UserRoleRepository extends JpaRepository<UserRoles,String> {
	
	@Query("select ur from UserRoles ur where ur.user.userName=:name")
	List<UserRoles> getUserRolesByName(@Param("name") String name);

}
