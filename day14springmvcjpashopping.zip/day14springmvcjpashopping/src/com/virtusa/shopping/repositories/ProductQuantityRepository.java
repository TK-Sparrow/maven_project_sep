package com.virtusa.shopping.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.shopping.models.ProductQuantity;

public interface ProductQuantityRepository extends JpaRepository<ProductQuantity,Integer> {

}
