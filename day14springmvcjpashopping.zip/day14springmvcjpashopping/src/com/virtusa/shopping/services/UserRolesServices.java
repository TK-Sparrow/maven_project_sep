package com.virtusa.shopping.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.UserRoles;
import com.virtusa.shopping.repositories.UserRoleRepository;

@Service
public class UserRolesServices {
	
	@Autowired
	private UserRoleRepository userRoleRepository;
	
	public List<UserRoles> getUserRoleByName(String userName) {
		
		return userRoleRepository.getUserRolesByName(userName);
	}
}
