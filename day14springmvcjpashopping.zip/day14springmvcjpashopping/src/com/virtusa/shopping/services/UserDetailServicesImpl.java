package com.virtusa.shopping.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User.UserBuilder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.User;


@Service("userDetailService")
public class UserDetailServicesImpl  implements UserDetailsService{
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRolesServices userRoleService;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		
		User user=userService.getUserByName(username);
		System.out.println("second "+user.getUserName());
		UserBuilder userBuilder=null;
		System.out.println("enable"+user.getEnabled());
		if(user!=null) {

			System.out.println("user done");
			userBuilder = org.springframework.security.core.userdetails.User.withUsername(username);
			if(user.getEnabled()==1) {
				userBuilder.disabled(false);
			}
			userBuilder.password(user.getPassword());
			String[] authorities=userRoleService.getUserRoleByName(username).stream().map(a -> a.getUserRoles()).toArray(String[]::new);
			userBuilder.authorities(authorities);
		}
		else {
			throw new UsernameNotFoundException("User Not Found");
		}
		
		return userBuilder.build();
	}

}
