package com.virtusa.corespringannotations.models;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

public class Transaction {
	private int transcationId;
	private Date dot;
	@Autowired
	private Account account;
	
	
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	
	public int getTranscationId() {
		return transcationId;
	}
	public void setTranscationId(int transcationId) {
		this.transcationId = transcationId;
	}
	public Date getDot() {
		return dot;
	}
	@Autowired
	public void setDot(Date dot) {
		this.dot = dot;
	}

	

}
