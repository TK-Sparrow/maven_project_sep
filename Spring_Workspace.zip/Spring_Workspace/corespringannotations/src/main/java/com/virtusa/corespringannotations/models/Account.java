package com.virtusa.corespringannotations.models;



public class Account {

	private String accountNumber;
	private String accountType;
	private String holderName;
	public Account(String accountNumber, String accountType, String holderName) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.holderName = holderName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

}
