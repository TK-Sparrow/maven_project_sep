package com.virtusa.corespringapp;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.virtusa.corespringapp.models.Customer;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Resource resource=new ClassPathResource("com/virtusa/corespringapp/resources/Customer-bean.xml");
    	BeanFactory beanFactory=new XmlBeanFactory(resource);
    	Customer customer1=(Customer) beanFactory.getBean("customer");
    	Customer customer2=(Customer) beanFactory.getBean("customer");
    	if(customer1.equals(customer2)) {
    		System.out.println("It is singleton");
    	}
    	else {
    		System.out.println("It is prototype");
    	}
    	customer1.setCustomerId(78654);
    	System.out.println("ID="+customer2.getCustomerId());
    	System.out.println("ID="+customer1.getCustomerId());
    	System.out.println("EMAIL="+customer1.getEmail());
    	System.out.println("DATE="+customer1.getDoj());
    	System.out.println("ASSETS="+customer1.getAssets());
    	
    	for(String asset:customer1.getAssets()) {
    		System.out.print(asset+" ");
    	}
    	
    }
}
