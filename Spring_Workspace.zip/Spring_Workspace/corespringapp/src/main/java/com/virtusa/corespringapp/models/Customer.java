package com.virtusa.corespringapp.models;

import java.util.Date;
import java.util.List;

public class Customer extends Person{
	
	private int CustomerId;
	private Date doj;
	private List<String> assets;
	
	public List<String> getAssets() {
		return assets;
	}
	public void setAssets(List<String> assets) {
		this.assets = assets;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public int getCustomerId() {
		return CustomerId;
	}
	public void setCustomerId(int customerId) {
		CustomerId = customerId;
	}

}
