/**
 * 
 */


window.addEventListener('load',function()
		{
	var ajaxObject=null;
	try{
		ajaxObject=new XMLHttpRequest();
	}
	catch(e){
		try{
			ajaxObject=new ActiveXObject("Msxml2.XMLHTTP3.0");
		}

		catch(e){
			alert("browser is broken or ajax ");
		}
	}




	document.querySelector("form").addEventListener("submit",function(){

		ajaxObject.open("post","../NewVehicleServletss",true);
		var regNo=document.querySelector("#register_number").value;
		var vmaker=document.querySelector("#vmaker").value;
		var chasisNo=document.querySelector("#chasis_number").value;
		var engineNo=document.querySelector("#engine_number").value;
		var color=document.querySelector("#color").value;
		var dor=document.querySelector("#date_of_reg").value;
		var fuelType=document.querySelector("#fueltype").value;
		ajaxObject.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
		ajaxObject.send("regNo="+regNo+"&vmaker="+vmaker+"&chasisNo="+chasisNo+"&engineNo="+engineNo+"&color="+color+"&dor="+dor+"&fuelType="+fuelType);
		
		var formRef=document.querySelector("form");
		
		ajaxObject.onreadystatechange=function()
		{
			if((ajaxObject.readyState==4) && (ajaxObject.status=200)){
				console.log(ajaxObject.responseText);
				element=document.createElement("p");
				textNode=document.createTextNode(ajaxObject.responseText);
				element.appendChild(textNode);
				formRef.appendChild(element);
			}
			
		}
		



	});
		});
