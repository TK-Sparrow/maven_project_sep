/**
 * 
 */


window.addEventListener('load',function()
		{
	var ajaxObject=null;
	try{
		ajaxObject=new XMLHttpRequest();
	}
	catch(e){
		try{
			ajaxObject=new ActiveXObject("Msxml2.XMLHTTP3.0");
		}

		catch(e){
			alert("browser is broken or ajax ");
		}
	}
	
	ajaxObject.open("get","../VehicleDisplay",true);
	ajaxObject.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
	ajaxObject.send(null);
	
	ajaxObject.onreadystatechange=function()
	{
		if((ajaxObject.readyState==4) && (ajaxObject.status=200)){
			
			data=JSON.parse(ajaxObject.responseText);
			
			var tableRef=document.querySelector("table");
			
			for(var pos in data){
				row=document.createElement("tr");
				for(var innerpos in data[pos]){
					col=document.createElement("td");
					textNode=document.createTextNode(innerpos.toUpperCase());
					col.appendChild(textNode);
					row.appendChild(col);				
			}
			tableRef.appendChild(row);
			break;
		}
			
			for(var pos in data){
				row=document.createElement("tr");
				for(var innerpos in data[pos]){
					col=document.createElement("td");
					if(typeof(data[pos][innerpos])=='object'){
						var date="";					
						for(var innermostpos in data[pos][innerpos]){
							date=data[pos][innerpos][innermostpos]+""+date;
							if(innermostpos != 'day'){
								date="-"+date;
							}
						}
						textNode=document.createTextNode(date+"");
					}
					else{					
						textNode=document.createTextNode(data[pos][innerpos]);
					}
					col.appendChild(textNode);
					row.appendChild(col);
					
				}
				tableRef.appendChild(row);
				
			}
			
		}
	}
	
});