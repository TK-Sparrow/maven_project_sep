package com.globalclaim.insurance.dao.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.globalclaim.insurance.models.Vehicle;

public interface VehicleDao {
		
	boolean addVehicle(Vehicle vehicle) throws SQLException;
	List<Vehicle> getAllVehicles() throws SQLException;
	Vehicle getVehicleById(String regNo);
	boolean updateVehicle(Vehicle vehicle);
	boolean deleteVehicle(String regNo);
	
}
