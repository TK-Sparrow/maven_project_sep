package com.globalclaim.insurance.dao.implementation;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.globalclaim.insurance.dao.interfaces.VehicleDao;
import com.globalclaim.insurance.helpers.OracleHelper;
import com.globalclaim.insurance.models.Vehicle;

public class VehicleImpl  implements VehicleDao{
	private Connection conn;
	private CallableStatement callable;
	private boolean status=false;
	private static ResourceBundle rb;
	private Statement statement;
	private ResultSet resultSet;

	{
		rb = ResourceBundle.getBundle("db");
	}
	
	
	@Override
	public boolean addVehicle(Vehicle vehicle) throws SQLException {
		conn=OracleHelper.getConnection();
		int result=0;
		try {
			conn.setAutoCommit(false);
			callable=conn.prepareCall("{call newvehicle (?,?,?,?,?,?,?)}");
			callable.setString(1,vehicle.getRegistration() );
			callable.setString(2,vehicle.getMaker());
			callable.setDate(3, Date.valueOf(vehicle.getDor()));
			callable.setString(4,vehicle.getChasisNo());
			callable.setString(5,vehicle.getEngineNo());
			callable.setString(6,vehicle.getFuelType());
			callable.setString(7,vehicle.getColor());
			result=callable.executeUpdate();
			if(result>0) {
				status=true;
			}
			conn.commit();
			
		} catch (SQLException e) {
			conn.rollback();
		}
		finally {
			conn.close();
		}
		return status;
	}

	@Override
	public List<Vehicle> getAllVehicles() throws SQLException {

		List<Vehicle> vehicles=new ArrayList<Vehicle>();
		Vehicle vehicle=null;
		conn=OracleHelper.getConnection();
		String getAllVehicleQuery=rb.getString("getallvehiclequery");
		try {
			statement=conn.createStatement();
			System.out.println("sqlwork...!");
			resultSet=statement.executeQuery(getAllVehicleQuery);
			System.out.println("sqlwork...!");
			
			while(resultSet.next()) {
				vehicle=new Vehicle();
				vehicle.setRegistration(resultSet.getString(1));
				vehicle.setMaker(resultSet.getString(2));
				vehicle.setDor(resultSet.getDate(3).toLocalDate());
				vehicle.setChasisNo(resultSet.getString(4));
				vehicle.setEngineNo(resultSet.getString(5));
				vehicle.setFuelType(resultSet.getString(6));
				vehicle.setColor(resultSet.getString(7));
				vehicles.add(vehicle);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			conn.close();
		}
		return vehicles;
	}

	@Override
	public Vehicle getVehicleById(String regNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateVehicle(Vehicle vehicle) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteVehicle(String regNo) {
		// TODO Auto-generated method stub
		return false;
	}

}
